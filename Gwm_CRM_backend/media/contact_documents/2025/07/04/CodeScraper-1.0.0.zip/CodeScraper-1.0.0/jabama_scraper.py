# Import necessary libraries for browser automation, parsing, waiting, and data handling
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
import time
import json
import os
import random 

# Scrapes data from a single property ad
def scraper_place_page(url, driver):
    try:
        driver.get(url)
        WebDriverWait(driver, 10)
        ec.presence_of_all_elements_located((By.TAG_NAME, "h1"))
        time.sleep(5)  # Wait for JavaScript content to load

        # استخراج id از URL
        url_parts = url.split('/')
        jabama_id = url_parts[-1] if url_parts[-1] else "unknown"  # بخش آخر URL (مثلاً villa-12345)

        try:
            title = driver.find_element(By.TAG_NAME, "h1").text
        except:
            title = "unknown"

        img_elements = driver.find_elements(By.CSS_SELECTOR, ".gallery img")
        img_links = []
        for i in img_elements:
            src = i.get_attribute("src")
            if src and "cdn.jabama.com" in src:
                img_links.append(src)

        specs = driver.find_elements(By.CLASS_NAME, "accommodation-pdp-specification-description__item")
        metr = next((s.text for s in specs if "متر" in s.text), "unknown")

        try:
            address = driver.find_element(By.CSS_SELECTOR, ".title strong").text
        except:
            address = "unknown"

        try:
            price = driver.find_element(By.CSS_SELECTOR, ".accommodation-pdp-sidebar-info-price-amount__price").text
        except:
            price = "unknown"    

        # Click to show all amenities
        try:
            show_all_btn = driver.find_element(By.XPATH, "//button[contains(text(), 'مشاهده‌ی همه‌ی امکانات')]")
            show_all_btn.click()
            time.sleep(1)
        except:
            pass

        try:
            facilities = []
            amenity_blocks = driver.find_elements(By.CSS_SELECTOR, "div.product-amenity")
            for block in amenity_blocks:
                class_name = block.get_attribute("class")
                if "missed" not in class_name:
                    span = block.find_element(By.CSS_SELECTOR, "span.product-amenity__text")
                    text = span.text.strip()
                    if text:
                        facilities.append(text)
        except:
            facilities = []

        try:
            rating_element = driver.find_element(By.CLASS_NAME, "rating-box__score")
            rating = rating_element.get_attribute("innerHTML").strip()
        except:
            rating = "unknown"    

        try:
            rules = []
            for el in driver.find_elements(By.CSS_SELECTOR, ".accommodation-additional-rules-list li"):
                text = el.get_attribute("innerText").strip()
                if text:
                    rules.append(text)
        except:
            rules = []

        try:
            checkin_time = "unknown"
            checkout_time = "unknown"
            time_blocks = driver.find_elements(By.CSS_SELECTOR, "div.product-check-in-time-item")
            for block in time_blocks:
                time_title = block.find_element(By.CLASS_NAME, "product-check-in-time-item__title").get_attribute("innerHTML").strip()
                time_value = block.find_element(By.CLASS_NAME, "product-check-in-time-item__time").get_attribute("innerHTML").strip()
                if "ورود" in time_title:
                    checkin_time = time_value
                elif "خروج" in time_title:
                    checkout_time = time_value
        except:
            checkin_time = checkout_time = "unknown"
            
        try:
            host_name = driver.find_element(By.CLASS_NAME, "j-list-text__title").get_attribute("innerHTML").strip()
        except:
            host_name = "unknown"

        try:
            capacity = "unknown"
            specs = driver.find_elements(By.CLASS_NAME, "accommodation-pdp-specification-description__item")
            for spec in specs:
                text = spec.get_attribute("innerHTML").strip()
                if "ظرفیت" in text:
                    capacity = text
        except:     
            capacity = "unknown"   

        #return scraped data
        result = {
            "id": jabama_id,  # اضافه کردن id استخراج‌شده از URL
            "url": url,
            "title": title,
            "img_links": list(set(img_links)),
            "metr": metr,
            "address": address,
            "price": price,
            "facilities": facilities,
            "rating": rating,
            "rules": rules,
            "checkin_time": checkin_time,
            "checkout_time": checkout_time,
            "host_name": host_name,
            "capacity": capacity
        }

        return result

    except Exception as e:
        print(f"Error scraping: {url} - {e}")
        return {
            "url": url,
            "error": str(e)
        }
#read lines from file and return cleaned list
def read_lines_from_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()
    return [line.strip() for line in lines if line.strip()] 

def get_urls_to_scrape():
    """Get URLs from detector that haven't been scraped yet"""
    try:
        # Read detector's output file
        with open('detected_urls.json', 'r') as f:
            all_urls = json.load(f)
        
        # Read already scraped URLs
        scraped_file = 'scraped_urls.json'
        if os.path.exists(scraped_file):
            with open(scraped_file, 'r') as f:
                scraped_urls = json.load(f)
        else:
            scraped_urls = []
        
        return [url for url in all_urls if url not in scraped_urls]
    
    except Exception as e:
        print(f"Error getting URLs to scrape: {str(e)}")
        return []

def mark_urls_as_scraped(urls):
    """Update the scraped URLs file"""
    try:
        scraped_file = 'scraped_urls.json'
        if os.path.exists(scraped_file):
            with open(scraped_file, 'r') as f:
                existing_urls = json.load(f)
        else:
            existing_urls = []
        updated_urls = list(set(existing_urls + urls))
        with open(scraped_file, 'w') as f:
            json.dump(updated_urls, f, indent=2)
    except Exception as e:
        print(f"Error marking URLs as scraped: {str(e)}")

def main():
    """main func that drives the scraping process"""
    chrome_options = Options()
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--disable-gpu")
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)

    links = get_urls_to_scrape()
    
    if not links:
        print("No new URLs to scrape")
        return

    # Load existing data from jabama_scraper.json (if exists)
    data_file = "jabama_scraper.json"
    if os.path.exists(data_file):
        with open(data_file, "r", encoding="utf-8") as f:
            all_data = json.load(f)

    all_data = []
    if os.path.exists(data_file):
        with open(data_file, "r", encoding="utf-8") as f:
            all_data = json.load(f)

    scraped_successfully = []

    total_links = len(links)
    for index, link in enumerate(links, start=1):
        result = scraper_place_page(link, driver)
        if "error" not in result:
            result["url"] = link
            all_data.append(result)
            scraped_successfully.append(link)
            print(f"Scraped {index} of {total_links}: {link}")
        else:
            print(f"Failed to scrape {index} of {total_links}: {link} — {result['error']}")

        time.sleep(random.uniform(1,5))#random delay to avoid detection   

    #save results to file
    with open(data_file, "w", encoding="utf-8") as f:
        json.dump(all_data, f, ensure_ascii=False, indent=4)

    mark_urls_as_scraped(scraped_successfully)

    driver.quit()

#run the script
if __name__ == "__main__":
    main()
