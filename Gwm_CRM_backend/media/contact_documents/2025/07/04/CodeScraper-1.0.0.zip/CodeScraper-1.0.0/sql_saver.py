# import necessary SQLAlchemy modules and PostgreSQL JSONB support
from sqlalchemy import create_engine, Text, Column, Integer, String, Time, Numeric 
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.dialects.postgresql import JSONB

# define the database URL and create the engine
db2_url = 'postgresql+pg8000://postgres:0880450789asnii@localhost:5432/codescraper'
engine = create_engine(db2_url)

# define the base class for ORM models
Base = declarative_base()

class Place(Base):
    """ Define the Place model (for house listings)"""
    __tablename__ = 'houses'
    id = Column(Integer, primary_key=True)
    source = Column(String)
    url = Column(Text)
    title = Column(String)
    address = Column(String)
    price = Column(String)
    area = Column(String)
    number_of_rooms = Column(String)
    construction_year = Column(String)
    facilities = Column(JSONB)
    image_links = Column(JSONB)
    rating = Column(Numeric(3, 2))
    rules = Column(JSONB)
    checkin_time = Column(Time)
    checkout_time = Column(Time)
    host_name = Column(String)
    capacity_min = Column(Integer)
    capacity_max = Column(Integer)

# create the table in the database if it doesn't already exist
Base.metadata.create_all(engine)

# create a session factory and a session object
Session = sessionmaker(bind=engine)
session = Session()
