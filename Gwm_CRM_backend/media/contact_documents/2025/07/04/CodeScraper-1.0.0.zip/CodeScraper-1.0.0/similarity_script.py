import pandas as pd
import numpy as np
import os
import shutil
from sklearn.preprocessing import MinMaxScaler
from scipy.spatial.distance import euclidean

def main(input_file="similarity_input.json"):
    try:
        # خواندن داده‌ها
        df = pd.read_json(input_file)

        # مدیریت مقادیر گمشده
        df["capacity"] = df["capacity"].fillna({})
        df["facilities"] = df["facilities"].fillna({})

        # استخراج capacity_min و capacity_max
        df["capacity_min"] = df["capacity"].apply(lambda x: x.get("standard/min", 0) if isinstance(x, dict) else 0)
        df["capacity_max"] = df["capacity"].apply(lambda x: x.get("max", 0) if isinstance(x, dict) else 0)

        # تبدیل facilities به ستون‌های باینری
        facilities_df = pd.json_normalize(df["facilities"]).fillna(0)

        # ترکیب DataFrame‌ها
        df = pd.concat([df, facilities_df], axis=1)

        # حذف ستون‌های غیرضروری
        df = df.drop(columns=["capacity", "facilities"], errors="ignore")

        # ذخیره داده‌های تمیز
        df.to_json("cleaned_data.json", index=False)

        # جدا کردن شهرها
        address = df["address"].str.split(",", expand=True)
        address["cities"] = address[0].str.strip()  # ستون اول به‌عنوان شهر
        folder_name = "cities"
        for folder in ["cities", "similarity_results"]:
                if os.path.exists(folder):
                    shutil.rmtree(folder)
                    print(f"Deleted existing folder: {folder}")
                os.makedirs(folder)
                print(f"Created new folder: {folder}")

        # گرفتن شهرهای منحصربه‌فرد
        unique_cities = address["cities"].dropna().unique()

        # فیلتر کردن و ذخیره داده‌ها برای هر شهر
        for city in unique_cities:
            filtered_df = df[address["cities"] == city]
            if not filtered_df.empty:
                output_file = os.path.join(folder_name, f"data_{city}.json")
                filtered_df.to_json(output_file, orient="records", force_ascii=False, lines=True)
                print(f"Data for city {city} saved to {output_file}")

        print(f"Processed {len(unique_cities)} cities.")

        # تنظیمات شباهت
        data_folder = "cities"
        output_folder = "similarity_results"
        numeric_features = ["price", "area", "capacity_min", "capacity_max"]
        facility_cols = ["pool", "parking", "wifi", "kitchen", "western_toilet", "iranian_toilet", "bathroom", "heating", "cooling", "jacuzzi", "television", "furniture", "breakfast"]
        threshold = 0.6
        jaccard_weight = 0.3
        euclidean_weight = 0.7
        min_rows = 5


        skipped_cities = []
        for city in unique_cities:
            file_path = os.path.join(data_folder, f"data_{city}.json")
            if not os.path.exists(file_path):
                print(f"No file found for {city}, skipping")
                skipped_cities.append({"city": city, "row_count": 0, "reason": "file not found"})
                continue
            
            df = pd.read_json(file_path, lines=True)
            if len(df) < min_rows:
                skipped_cities.append({"city": city, "row_count": len(df), "reason": f"only {len(df)} rows"})
                print(f"Skipping {city} (only {len(df)} rows, need at least {min_rows})")
                continue

            print(f"Processing {city} ({len(df)} rows)")

            # نرمال‌سازی ویژگی‌های عددی
            scaler = MinMaxScaler()
            valid_numeric_features = [col for col in numeric_features if col in df.columns]
            if not valid_numeric_features:
                print(f"No numeric features for {city}, skipping")
                skipped_cities.append({"city": city, "row_count": len(df), "reason": "no numeric features"})
                continue
            numeric_matrix = scaler.fit_transform(df[valid_numeric_features])

            # ماتریس امکانات
            valid_facility_cols = [col for col in facility_cols if col in df.columns]
            if not valid_facility_cols:
                print(f"No facility columns for {city}, skipping")
                skipped_cities.append({"city": city, "row_count": len(df), "reason": "no facility columns"})
                continue
            facility_matrix = df[valid_facility_cols].to_numpy()

            # محاسبه شباهت
            similarities = []
            for i in range(len(df)):
                for j in range(i + 1, len(df)):
                    jaccard_sim = np.mean(facility_matrix[i] == facility_matrix[j])
                    euc_dist = euclidean(numeric_matrix[i], numeric_matrix[j])
                    euc_sim = 1 / (1 + euc_dist)
                    combined_sim = jaccard_weight * jaccard_sim + euclidean_weight * euc_sim
                    if combined_sim > threshold:
                        similarities.append({
                            "id_1": df.iloc[i]["id"],
                            "id_2": df.iloc[j]["id"],
                            "address_1": df.iloc[i]["address"],
                            "url1": df.iloc[i]["url"],
                            "address_2": df.iloc[j]["address"],
                            "url2": df.iloc[j]["url"],
                            "jaccard_similarity": jaccard_sim,
                            "euclidean_similarity": euc_sim,
                            "combined_similarity": combined_sim
                        })

            output_file = os.path.join(output_folder, f"similarity_{city}.csv")
            if similarities:
                pd.DataFrame(similarities).to_csv(output_file, index=False)
                print(f"Saved {len(similarities)} pairs to {output_file}")
            else:
                print(f"No similar pairs found for {city}")

        if skipped_cities:
            pd.DataFrame(skipped_cities).to_csv(os.path.join(output_folder, "skipped_cities.csv"), index=False)
            print(f"Saved {len(skipped_cities)} skipped cities to {output_folder}/skipped_cities.csv")
        else:
            print("No cities were skipped.")

    except Exception as e:
        print(f"Error processing data: {e}")
        exit(1)

if __name__ == "__main__":
    import sys
    input_file = sys.argv[1] if len(sys.argv) > 1 else "similarity_input.json"
    main(input_file)