import json
import re
from typing import List, Dict, Any
import logging
import uuid
import schedule
import time
import sys
# importing similairity script
from similarity_script import main as main_similarity


# ##############database###########
from datetime import datetime
from sqlalchemy.exc import IntegrityError
from sqlalchemy import select
from sql_saver import Session, Place

def save_to_db(data, session):
    inserted = 0
    skipped = 0

    for item in data:
        item_id = item['id']
        exists = session.query(Place.id).filter_by(id=item_id).first()
        if exists:
            skipped += 1
            continue
        def to_time(t):
            try:
                return datetime.strptime(t, "%H:%M").time()
            except:
                return None

        new_place = Place(
            id=item_id,
            source=item['source'],
            url=item['url'],
            title=item['title'],
            address=item['address'],
            price=item['price'],
            area=item['area'],
            number_of_rooms=item['number_of_rooms'],
            construction_year=item['construction_year'],
            facilities=item['facilities'],
            image_links=item['image_links'],
            rating=float(item['rating']) if item['rating'] != 'not specified' else None,
            rules=item['rules'],
            checkin_time=to_time(item['checkin_time']),
            checkout_time=to_time(item['checkout_time']),
            host_name=item['host_name'],
            capacity_min=item['capacity']['standard/min'],
            capacity_max=item['capacity']['max']
        )
        try:
            session.add(new_place)
            inserted += 1
        except IntegrityError:
            skipped += 1

    session.commit()
    logger.info(f"{inserted} new items inserted into database, {skipped} skipped (already exist).")
# ##############database###########


# تنظیم لاگینگ برای پشتیبانی از UTF-8 و نمایش در کنسول
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# تنظیم فرمت لاگ‌ها برای نمایش زمان، سطح و پیام
console_handler = logging.StreamHandler(stream=sys.stdout)
console_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
console_handler.setStream(sys.stdout)
console_handler.stream.reconfigure(encoding='utf-8')
logger.handlers = [console_handler]

class Cleaner:



    PERSIAN_TO_FINGLISH = {
        'ا': 'a', 'آ': 'a', 'ب': 'b', 'پ': 'p', 'ت': 't', 'ث': 's', 'ج': 'j', 'چ': 'ch',
        'ح': 'h', 'خ': 'kh', 'د': 'd', 'ذ': 'z', 'ر': 'r', 'ز': 'z', 'ژ': 'zh', 'س': 's',
        'ش': 'sh', 'ص': 's', 'ض': 'z', 'ط': 't', 'ظ': 'z', 'ع': 'a', 'غ': 'gh', 'ف': 'f',
        'ق': 'gh', 'ک': 'k', 'گ': 'g', 'ل': 'l', 'م': 'm', 'ن': 'n', 'و': 'v', 'ه': 'h',
        'ی': 'y', ' ': '_', 'ة': 'h', 'ئ': 'y', 'ء': '', '،': '', '؛': '', '؟': '',
        '"': '', '(': '', ')': '', '-': '_', '.': ''
    }

    # لیست کلمات غیرضروری در عنوان (استفاده نشده)
    TITLE_STOPWORDS = [
        'residence', 'ecotourism', 'eco_tourism', 'rent', 'with_parking', 'has',
        'villa', 'suite', 'room', 'unit'
    ]

    def __init__(self, shab_file: str, jabama_file: str):
       
        self.shab_file = shab_file  # مسیر فایل داده‌های shab
        self.jabama_file = jabama_file  # مسیر فایل داده‌های jabama
        self.shab_data = []  # ذخیره داده‌های shab
        self.jabama_data = []  # ذخیره داده‌های jabama
        self.load_data() 

    def load_data(self):
        """بارگذاری داده‌های JSON از فایل‌ها"""
        self.shab_data = self._load_json(self.shab_file)  
        self.jabama_data = self._load_json(self.jabama_file) 
        logger.debug(f"Loaded {len(self.shab_data)} items from {self.shab_file}") 
        logger.debug(f"Loaded {len(self.jabama_data)} items from {self.jabama_file}")  

    def _load_json(self, file_path: str) -> List[Dict[str, Any]]:

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f) 
        except Exception as e:
            logging.error(f"Error reading file {file_path}: {str(e)}")  # لاگ خطا
            return []  

    def _extract_number(self, text: str) -> float:
        """استخراج عدد از رشته (مثل قیمت یا مساحت)"""
        if not text or text in ["unknown", "not specified"]:
            return 0  # بازگشت صفر برای داده‌های نامعتبر
        cleaned = re.sub(r'[^\d.]', '', str(text))  # حذف کاراکترهای غیرعددی
        try:
            return float(cleaned)  # تبدیل به عدد اعشاری
        except ValueError:
            return 0  

    def _format_price(self, price: str) -> str:
        """فرمت‌بندی قیمت به شکل 3,250,000 Toman"""
        num = self._extract_number(price)  
        if num == 0:
            return "not specified"  
        formatted = f"{int(num):,}"  # فرمت‌بندی با کاما
        return f"{formatted} Toman"  # افزودن واحد تومان

    def _clean_time(self, time_str: str) -> str:
        """استانداردسازی زمان به فرمت 24 ساعته HH:MM"""
        if not time_str or time_str in ["not specified", "unknown"]:
            return "not specified"
        match = re.search(r'(\d{1,2}):(\d{2})', time_str)  
        if not match:
            return "not specified"  
        hour, minute = match.groups()  # گرفتن ساعت و دقیقه
        hour = int(hour)  # تبدیل ساعت به عدد
        is_afternoon = "afternoon" in time_str or "noon" in time_str  # بررسی بعدازظهر
        if is_afternoon and hour != 12:
            hour += 12  # تبدیل به فرمت 24 ساعته
        elif not is_afternoon and hour == 12:
            hour = 0  # تبدیل 12 صبح به 00
        elif is_afternoon and hour == 12:
            hour = 12  # نگه‌داشتن 12 بعدازظهر
        return f"{hour:02d}:{minute}"  # بازگشت فرمت HH:MM

    def _clean_rules(self, rules: Any) -> List[str]:
        """تبدیل قوانین به لیست رشته‌ها"""
        if not rules:
            return ["none"]  
        if isinstance(rules, dict):
            result = []
            if rules.get("rules_description"):
                result.extend(rules["rules_description"].split('\n'))  
            for key, value in rules.items():
                if key in ["smoking", "pets_allowed", "ceremony_allowed", "single_group"] and value == 1:
                    translations = {
                        "smoking": "smoking allowed",
                        "pets_allowed": "pets allowed",
                        "ceremony_allowed": "ceremonies allowed",
                        "single_group": "single groups allowed"
                    }
                    result.append(translations.get(key, ""))  
            return [r.strip() for r in result if r.strip()] 
        elif isinstance(rules, list):
            return [r.strip() for r in rules if r.strip()]  
        return ["none"]  

    def _clean_facilities(self, facilities: List[str]) -> List[str]:
        """تمیز کردن امکانات و حذف موارد تکراری"""
        if not facilities:
            return ["none"]  
        return sorted(list(set(f.strip() for f in facilities if f.strip()))) 

    def _clean_capacity(self, capacity: str) -> Dict[str, int]:
        """تمیز کردن ظرفیت به دیکشنری با حداقل و حداکثر"""
        if not capacity or capacity in ["unknown", "not specified"]:
            return {"standard/min": 0, "max": 0}  
        shab_match = re.match(r'standard(\d+)\s*/\s*maximum\s*(\d+)', capacity)  # فرمت shab
        jabama_match1 = re.match(r'capacity up to (\d+) people\s*\((\d+) base \+ up to (\d+) extra\)', capacity)  # فرمت jabama 1
        jabama_match2 = re.match(r'capacity (\d+) people', capacity)  # فرمت jabama 2
        if shab_match:
            min_val, max_val = shab_match.groups()  # استخراج حداقل و حداکثر
            min_val, max_val = int(min_val), int(max_val)
        elif jabama_match1:
            total_val, base_val, _ = jabama_match1.groups()  # استخراج پایه و کل
            min_val, max_val = int(base_val), int(total_val)
        elif jabama_match2:
            total_val = jabama_match2.group(1)  # استخراج ظرفیت
            min_val = max_val = int(total_val)
        else:
            numbers = re.findall(r'\d+', capacity)  # استخراج اعداد
            if len(numbers) >= 2:
                min_val, max_val = int(numbers[0]), int(numbers[1])
            elif len(numbers) == 1:
                min_val = max_val = int(numbers[0])
            else:
                min_val = max_val = 0
        return {"standard/min": min_val, "max": max_val}  # بازگشت دیکشنری ظرفیت

    def _safe_convert_to_float(self, value: Any) -> float:
        """تبدیل ایمن مقدار به عدد اعشاری"""
        try:
            return float(value)  
        except (ValueError, TypeError):
            return 0.0  

    def _clean_text_to_words_only(self, text: str) -> str:
        """تمیز کردن متن برای نگه‌داشتن فقط حروف و اعداد"""
        if not text or text == "not specified":
            return "not specified"  
        cleaned = re.sub(r'[^ا-یa-zA-Z0-9\s]', '', text)  
        return ' '.join(word for word in cleaned.split() if word) 

    def _clean_address_for_similarity(self, address: str) -> str:
        """استخراج نام شهر از آدرس برای الگوریتم شباهت"""
        if not address or address in ["not specified", "unknown"]:
            return "not specified"  
        parts = [part.strip() for part in address.split('،')]  # جداسازی بخش‌ها
        if not parts:
            return "not specified" 
        city = parts[-1]  # گرفتن آخرین بخش به‌عنوان شهر
        return f"{city},"  # افزودن کاما

    def clean_all_data(self) -> List[Dict[str, Any]]:
        """تمیز کردن و یکسان‌سازی تمام داده‌ها"""
        cleaned_data = []
        for item in self.shab_data:
            cleaned_item = {
                "source": "shab",  # منبع داده
                "id": item.get("id", str(uuid.uuid4())),  # شناسه یکتا
                "url": item.get("url", "not specified"),  # لینک آگهی
                "title": item.get("title", "not specified").strip(),  # عنوان
                "address": item.get("address", "not specified").strip(),  # آدرس
                "price": self._format_price(item.get("price", "not specified")),  # قیمت
                "area": str(int(self._extract_number(item.get("metr", "0")))) + " meters" if item.get("metr", "0") != "unknown" else "not specified",  # مساحت
                "number_of_rooms": "not specified",  # تعداد اتاق (مشخص نشده)
                "construction_year": "not specified",  # سال ساخت (مشخص نشده)
                "facilities": self._clean_facilities(item.get("facilities", [])),  # امکانات
                "image_links": item.get("img_liks", []),  # لینک تصاویر
                "rating": str(item.get("rating", "not specified")),  # امتیاز
                "rules": self._clean_rules(item.get("rules", {})),  # قوانین
                "checkin_time": self._clean_time(item.get("checkin_time", "not specified")),  # زمان ورود
                "checkout_time": self._clean_time(item.get("checkout_time", "not specified")),  # زمان خروج
                "host_name": item.get("host_name", "not specified").strip(),  # نام میزبان
                "capacity": self._clean_capacity(item.get("capacity", "not specified"))  # ظرفیت
            }
            cleaned_data.append(cleaned_item)  # افزودن به لیست داده‌های تمیز

        for item in self.jabama_data:
            cleaned_item = {
                "source": "jabama",  # منبع داده
                "id": item.get("id", str(uuid.uuid4())),  # شناسه یکتا
                "url": item.get("url", "not specified"),  # لینک آگهی
                "title": item.get("title", "not specified").strip(),  # عنوان
                "address": item.get("address", "not specified").strip(),  # آدرس
                "price": self._format_price(item.get("price", "not specified")),  # قیمت
                "area": str(int(self._extract_number(item.get("metr", "0")))) + " meters" if item.get("metr", "0") != "unknown" else "not specified",  # مساحت
                "number_of_rooms": "not specified",  # تعداد اتاق (مشخص نشده)
                "construction_year": "not specified",  # سال ساخت (مشخص نشده)
                "facilities": self._clean_facilities(item.get("facilities", [])),  # امکانات
                "image_links": item.get("img_links", []),  # لینک تصاویر
                "rating": str(item.get("rating", "not specified")),  # امتیاز
                "rules": self._clean_rules(item.get("rules", [])),  # قوانین
                "checkin_time": self._clean_time(item.get("checkin_time", "not specified")),  # زمان ورود
                "checkout_time": self._clean_time(item.get("checkout_time", "not specified")),  # زمان خروج
                "host_name": item.get("host_name", "not specified").strip(),  # نام میزبان
                "capacity": self._clean_capacity(item.get("capacity", "not specified"))  # ظرفیت
            }
            cleaned_data.append(cleaned_item)  # افزودن به لیست داده‌های تمیز

        return cleaned_data  # بازگشت داده‌های تمیز شده

    def normalize_facility(self, facility: str) -> str:
        """نرمال‌سازی نام امکانات برای مقایسه"""
        return facility.strip().lower().replace(" ", "")  # حذف فاصله و تبدیل به حروف کوچک

    def clean_for_similarity(self) -> List[Dict[str, Any]]:
        """تمیز کردن داده‌ها برای الگوریتم شباهت با فیلدهای محدود"""
        similarity_data = []
        key_facilities = [
            "pool", "parking", "wifi", "kitchen", "western_toilet", "iranian_toilet",
            "bathroom", "heating", "cooling", "jacuzzi", "television", "furniture", "breakfast"
        ]  # امکانات کلیدی
        facility_mapping = {
            "pool": "pool", "استخر": "pool",
            "parking": "parking", "پارکینگ": "parking",
            "internet (Wifi)": "wifi", "اینترنت (وای‌فای)": "wifi", "internet wifi": "wifi",
            "kitchen": "kitchen", "آشپزخانه": "kitchen", "refrigerator": "kitchen", "یخچال": "kitchen",
            "stove": "kitchen", "اجاق گاز": "kitchen", "cookware": "kitchen", "ظروف پخت و پز": "kitchen",
            "serving utensils": "kitchen", "ظروف سرو غذا": "kitchen", "sink": "kitchen", "سینک ظرفشویی": "kitchen",
            "pots and pans": "kitchen", "ماهیتابه / قابلمه": "kitchen", "samovar tea maker": "kitchen", "سماور / چای ساز": "kitchen",
            "skewer": "kitchen", "سیخ": "kitchen", "western toilet": "western_toilet", "توالت فرنگی": "western_toilet",
            "سرویس بهداشتی فرنگی": "western_toilet", "portable western toilet": "western_toilet", "فرنگی سیار": "western_toilet",
            "iranian toilet": "iranian_toilet", "سرویس بهداشتی ایرانی": "iranian_toilet", "bathroom": "bathroom", "حمام": "bathroom",
            "heating system": "heating", "سیستم گرمایشی": "heating", "radiator": "heating", "شوفاژ": "heating",
            "fan coil": "heating", "فن‌کوئل": "heating", "heater": "heating", "بخاری": "heating",
            "gas heater": "heating", "بخاری گازی": "heating", "electric heater": "heating", "بخاری برقی": "heating",
            "oil heater": "heating", "بخاری نفتی": "heating", "package heating": "heating", "پکیج": "heating",
            "korsi": "heating", "کرسی": "heating", "fireplace": "heating", "شومینه": "heating",
            "cooling system": "cooling", "سیستم سرمایشی": "cooling", "air conditioner": "cooling", "کولر گازی": "cooling",
            "split ac": "cooling", "اسپلیت": "cooling", "water cooler": "cooling", "evaporative cooler": "cooling",
            "کولر آبی": "cooling", "fan": "cooling", "فن": "cooling", "پنکه": "cooling", "ceiling fan": "cooling",
            "پنکه سقفی": "cooling", "jacuzzi": "jacuzzi", "جکوزی": "jacuzzi", "television": "television",
            "تلویزیون": "television", "digital receiver": "television", "گیرنده دیجیتال": "television",
            "furniture": "furniture", "مبلمان": "furniture", "dining table": "furniture", "میز ناهارخوری": "furniture",
            "closet drawer": "furniture", "کمد/دراور": "furniture", "breakfast": "breakfast", "صبحانه": "breakfast"
        }  # نگاشت امکانات به انگلیسی

        for item in self.shab_data:
            facilities = item.get("facilities", [])  # گرفتن امکانات
            facility_flags = {f: 0 for f in key_facilities}
            for f in facilities:
                f_cleaned = self.normalize_facility(f)  
                for persian_f, english_f in facility_mapping.items():
                    if self.normalize_facility(persian_f) in f_cleaned or self.normalize_facility(english_f) in f_cleaned:
                        facility_flags[english_f] = 1 
                        break
            capacity_dict = self._clean_capacity(item.get("capacity", "not specified"))  
            similarity_data.append({
                "id": item.get("id", str(uuid.uuid4())),  # شناسه
                "title": self._clean_text_to_words_only(item.get("title", "not specified").strip()),  # عنوان تمیز
                "url": item.get("url", "not specified"),  # لینک
                "source": "shab",  # منبع
                "address": self._clean_address_for_similarity(item.get("address", "not specified")),  # آدرس تمیز
                "price": self._extract_number(item.get("price", "0")),  # قیمت عددی
                "area": self._extract_number(item.get("metr", "0")),  # مساحت عددی
                "capacity": capacity_dict,  # ظرفیت
                "rating": self._safe_convert_to_float(item.get("rating", 0)),  # امتیاز
                "image_links": item.get("img_liks", []),  # لینک تصاویر
                "facilities": facility_flags  # فلگ‌های امکانات
            })

        for item in self.jabama_data:
            facilities = item.get("facilities", []) 
            facility_flags = {f: 0 for f in key_facilities}
            for f in facilities:
                f_cleaned = self.normalize_facility(f)
                for persian_f, english_f in facility_mapping.items():
                    if self.normalize_facility(persian_f) in f_cleaned or self.normalize_facility(english_f) in f_cleaned:
                        facility_flags[english_f] = 1 
                        break
            capacity_dict = self._clean_capacity(item.get("capacity", "not specified"))  # تمیز کردن ظرفیت
            similarity_data.append({
                "id": item.get("id", str(uuid.uuid4())),  # شناسه
                "title": self._clean_text_to_words_only(item.get("title", "not specified").strip()),  # عنوان تمیز
                "url": item.get("url", "not specified"),  # لینک
                "source": "jabama",  # منبع
                "address": self._clean_address_for_similarity(item.get("address", "not specified")),  # آدرس تمیز
                "price": self._extract_number(item.get("price", "0")),  # قیمت عددی
                "area": self._extract_number(item.get("metr", "0")),  # مساحت عددی
                "capacity": capacity_dict,  # ظرفیت
                "rating": self._safe_convert_to_float(item.get("rating", 0)),  # امتیاز
                "image_links": item.get("img_links", []),  # لینک تصاویر
                "facilities": facility_flags  # فلگ‌های امکانات
            })

        return similarity_data  # بازگشت داده‌های تمیز برای شباهت

    def save_output(self, data: List[Dict[str, Any]], output_file: str):
        """ذخیره داده‌ها در فایل JSON"""
        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2) 
            logging.info(f"Data saved to {output_file}") 
        except Exception as e:
            logging.error(f"Error saving file {output_file}: {str(e)}")  

    def run(self):
        """اجرای فرآیند تمیز کردن و ذخیره خروجی‌ها"""
        logging.info("Starting data cleaning process") 
        cleaned_all = self.clean_all_data()  # تمیز کردن تمام داده‌ها
        self.save_output(cleaned_all, "cleaned_all_data.json")  # ذخیره داده‌های کامل

        ##############database###########
        session = Session()
        save_to_db(cleaned_all, session)
        session.close()
        ##############database###
        
        similarity_data = self.clean_for_similarity()  # تمیز کردن برای شباهت
        self.save_output(similarity_data, "similarity_input.json")  # ذخیره داده‌های شباهت
        logging.info("Data cleaning process completed")  # لاگ پایان
    @staticmethod
    def RUN_similarity():
        logging.info("strating similaity algorithm")
        main_similarity()
        logging.info("similar data collected")
    def clean_pipeline(self):
        """اجرای فرآیند تمیز کردن (برای سازگاری با اسکریپت‌های قدیمی)"""
        self.run()  # اجرای فرآیند تمیز کردن

def main():
    """تابع اصلی برای اجرای دوره‌ای کلینر"""
    cleaner = Cleaner(
        shab_file="shab_detailed_data.json",  # فایل داده‌های shab
        jabama_file="jabama_scraper.json"  # فایل داده‌های jabama
    )
    cleaner.run()  # اجرای اولیه
    schedule.every(1).minutes.do(cleaner.load_data)  # زمان‌بندی بارگذاری داده‌ها
    schedule.every(1).minutes.do(cleaner.run)  # زمان‌بندی اجرای تمیز کردن
    schedule.every(1).minutes.do(cleaner.RUN_similarity) #اجرای الگوریتم تشابه
    logging.info("Starting scheduling loop for execution every 5 minutes")  # لاگ شروع
    while True:
        schedule.run_pending()  # اجرای وظایف زمان‌بندی‌شده
        time.sleep(1)  # انتظار برای دور بعدی
