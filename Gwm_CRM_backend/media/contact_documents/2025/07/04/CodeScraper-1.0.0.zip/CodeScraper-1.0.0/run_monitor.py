
import time
import subprocess
import logging
from detector import JabamaDetector
import sys 

subprocess.run([sys.executable, "jabama_scraper.py"], check=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

def run_detector():
    """Run the detector script"""
    detector = JabamaDetector()
    new_urls = detector.detect_new_listings()
    return new_urls

def run_scraper():
    """Run the scraper script"""
    subprocess.run(["python", "jabama_scraper.py"], check=True)

def run_cleaner():
    """Run the cleaner script"""
    subprocess.run(["python", "cleaner.py"], check=True)

def main():
    interval = 300  # 5 minutes
    pages = 5
    detector = JabamaDetector()
    new_urls = detector.detect_old_listings(pages)
    run_scraper()
    run_cleaner()
    while True:
        try:
            logging.info(f"Running detector (scanning {pages} pages)...")
            new_urls = run_detector()
            
            if new_urls:
                logging.info(f"Found {len(new_urls)} new listings, running scraper...")
                run_scraper()
                logging.info("Running cleaner...")
                run_cleaner()
            else:
                logging.info("No new listings found")
            
            logging.info(f"Waiting {interval} seconds before next check...")
            time.sleep(interval)
            
        except KeyboardInterrupt:
            logging.info("Stopping monitor...")
            break
        except Exception as e:
            logging.error(f"Error: {str(e)}")
            time.sleep(60)  # Wait a minute before retrying

if __name__ == "__main__":
    main()
