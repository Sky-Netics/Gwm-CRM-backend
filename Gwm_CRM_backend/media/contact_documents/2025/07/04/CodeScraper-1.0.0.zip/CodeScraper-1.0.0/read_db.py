from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sql_saver import Place  

db_url = 'postgresql+pg8000://postgres:0880450789asnii@localhost:5432/codescraper'
engine = create_engine(db_url)
Session = sessionmaker(bind=engine)
session = Session()


places = session.query(Place).limit(10).all()

for p in places:
    print(f"{p.id} - {p.title} - {p.price} - {p.address}")

session.close()