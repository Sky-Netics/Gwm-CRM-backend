import requests
import json
import time
import shab_scraper

# file to store all fetched house data
all_data_file = "shab_all_data.json"

# load existing data from JSON file, if it exists
def load_existing_data():    
    try:
        with open(all_data_file, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return []  

# save updated data to the JSON file
def save_updated_data(all_data):    
    with open(all_data_file, "w", encoding="utf-8") as f:
        json.dump(all_data, f, ensure_ascii=False, indent=4)

# fetch new house listings from the Shab API for a given page number
def fetch_new_houses(page=1):
    url = "https://api.shab.ir/api/fa/sandbox/v_1_4/house/search"
    params = {
        "category[]": "boomgardi",  
        "meta_tags[]": "boomgardi",  
        "perpage": 24,
        "page": page,
        "with[]": "photos"
    }
    try:
        response = requests.get(url, params=params)
        if response.status_code == 200:
            data = response.json()
            return data.get("data", {}).get("records", []) # return list o houses
    except Exception as e:
        print(f"Error fetching house list: {e}")
    return [] # return empty list on error

# main func to manage scraping logic
def main():
    existing_data = load_existing_data()
    existing_ids = {house["id"] for house in existing_data} # create a set of already scraped house IDs  

    new_houses = [] # store newly found houses 

    for page in range(1, 6): # loop through  first 5 pages
        print(f"Fetching houses from page {page}...")
        houses_on_page = fetch_new_houses(page)

        #check for houses not already stored
        for house in houses_on_page:
            if house["id"] not in existing_ids: 
                new_houses.append(house)
        print(f"Fetched {len(houses_on_page)} houses from page {page}")
        time.sleep(2) # delay between page requests

    if new_houses:
        print(f"{len(new_houses)} new houses found.")
        existing_data.extend(new_houses) # ad new houses to existing data
        save_updated_data(existing_data)

        print("starting detailed scraper...")  
        shab_scraper.main() # call scraper 
    else:
        print("No new houses found.")

#repeatedly run main() every 5 minutes
if __name__ == "__main__":
    while True:
        main()
        time.sleep(300)  