import requests
from bs4 import BeautifulSoup
import time
import json
from urllib.parse import urljoin
import logging
import os
import argparse


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('detector.log'),
        logging.StreamHandler()
    ]
)

class BaseDetector:
    """Base class for all detectors with common functionality"""
    
    def __init__(self, base_url, name, output_file='detected_urls.json'):
        self.base_url = base_url
        self.name = name
        self.output_file = output_file
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        
        # Create output file if it doesn't exist
        if not os.path.exists(self.output_file):
            with open(self.output_file, 'w') as f:
                json.dump([], f)
    
    def get_page_content(self, url):
        """Fetch page content with error handling and delays"""
        try:
            time.sleep(2)  #delay between requests
            response = self.session.get(url)
            response.raise_for_status()
            return response.text
        except requests.exceptions.RequestException as e:
            logging.error(f"Error fetching {url}: {str(e)}")
            return None
    def save_urls(self, urls):
        """Save detected URLs to the output file"""
        try:
            # Read existing URLs
            with open(self.output_file, 'r') as f:
                existing_urls = json.load(f)
            
            # Add new URLs that aren't already present
            new_urls = [url for url in urls if url not in existing_urls]
            
            if new_urls:
                existing_urls.extend(new_urls)
                with open(self.output_file, 'w') as f:
                    json.dump(existing_urls, f, indent=2)
                logging.info(f"Saved {len(new_urls)} new URLs to {self.output_file}")
            else:
                logging.info("No new URLs found to save")
                
            return new_urls
        except Exception as e:
            logging.error(f"Error saving URLs: {str(e)}")
            return []
    
    def extract_listing_urls(self, html):
        """To be implemented by child classes"""
        raise NotImplementedError("This method must be implemented by subclasses")

class JabamaDetector(BaseDetector):
    """Detector for jabama.com website"""
    
    def __init__(self):
        super().__init__(
            base_url="https://www.jabama.com/all-ecotourism",
            name="Jabama Detector"
        )
        self.last_scan_time = None
        self.last_scan_count = 0

    def extract_listing_urls(self, html):
        """Extract listing URLs from jabama.com HTML"""
        soup = BeautifulSoup(html, 'html.parser')
        urls = []
        
        # Find listing links by their css selector
        listing_cards = soup.select('a[href^="/stay/"][rel="bookmark"][target="_blank"]:has(article.product-card)')
        
        for card in listing_cards:
            href = card.get('href')
            if href:
                full_url = urljoin(self.base_url, href)
                urls.append(full_url)
        
        return urls
    
    def detect_old_listings(self, pages=5):
        """Detect older listings by paginating through the site"""
        all_urls = []
        
        for page in range(1, pages + 1):
            url = f"{self.base_url}?page-number={page}"
            logging.info(f"Scanning page {page}: {url}")
            
            html = self.get_page_content(url)
            if not html:
                continue
                
            page_urls = self.extract_listing_urls(html)

            all_urls.extend(page_urls)
                        
            if not page_urls:
                break  # No more listings 
        return self.save_urls(all_urls)
            
    def detect_new_listings(self):
        """Detect new listings from the first page with timestamp comparison"""
        logging.info("Scanning for new listings...")
        html = self.get_page_content(self.base_url)
        if not html:
            return []
                    
        current_urls = self.extract_listing_urls(html)
        self.last_scan_count = len(current_urls)
        self.last_scan_time = time.strftime('%Y-%m-%d %H:%M:%S')
        
        return self.save_urls(current_urls)
    
    def get_scan_stats(self):
        """Return statistics about the last scan"""
        return {
            'last_scan_time': self.last_scan_time,
            'last_scan_count': self.last_scan_count
        }
    
    def get_new_urls_since_last_check(self):
        """Returns only URLs that haven't been scraped yet"""
        try:
            # Read all detected URLs
            with open('detected_urls', 'r') as f:
                all_urls = json.load(f)
            
            # Read scraped URLs if the file exists
            scraped_file = 'scraped_urls.json'
            if os.path.exists(scraped_file):
                with open(scraped_file, 'r') as f:
                    scraped_urls = json.load(f)
            else:
                scraped_urls = []
            
            # Return only URLs that haven't been scraped
            return [url for url in all_urls if url not in scraped_urls]
        
        except Exception as e:
            logging.error(f"Error checking new URLs: {str(e)}")
            return []

    
def run_detector(mode, site, pages=5):
    """Run the detector in specified mode for the specified site"""
    if site == 'jabama':
        detector = JabamaDetector()
    else:
        raise ValueError("Invalid site specified.")
    
    if mode == 'old':
        logging.info(f"Running old detector for {site} (scanning {pages} pages)")
        return detector.detect_old_listings(pages)
    elif mode == 'new':
        logging.info(f"Running new detector for {site}")
        return detector.detect_new_listings()
    else:
        raise ValueError("Invalid mode specified. Use 'old' or 'new'")

# Global variable to control the monitoring loop
monitoring_active = True

def signal_handler(sig, frame):
    """Handle interrupt signal to stop monitoring gracefully"""
    global monitoring_active
    logging.info("\nReceived interrupt signal. Stopping monitoring...")
    monitoring_active = False

def main():
    parser = argparse.ArgumentParser(description='Real Estate Listing Detector')
    parser.add_argument('--mode', choices=['old', 'new'], required=True,
                       help='Detection mode: "old" for scanning old listings, "new" for detecting new listings')
    parser.add_argument('--site', choices=['jabama', 'shab'], required=True,
                       help='Site to scan: "jabama" or "shab"')
    parser.add_argument('--pages', type=int, default=5,
                       help='Number of pages to scan (for old detector mode)')
    parser.add_argument('--interval', type=int, default=300,
                       help='Interval in seconds between scans (for new detector mode)')
    
    args = parser.parse_args()
    
    if args.mode == 'new':
        # Continuous monitoring for new listings
        global monitoring_active
        detector = JabamaDetector() if args.site == 'jabama' else None
        
        # Initial scan
        run_detector(args.mode, args.site)
        
        # Continuous monitoring loop
        while monitoring_active:
            logging.info(f"Waiting {args.interval} seconds before next scan...")
            
            # Sleep in smaller chunks to allow for interrupt response
            for _ in range(args.interval):
                if not monitoring_active:
                    break
                time.sleep(1)
            
            if monitoring_active:
                new_urls = run_detector(args.mode, args.site)
                stats = detector.get_scan_stats()
                logging.info(f"Scan statistics - Last scan: {stats['last_scan_time']}, Listings found: {stats['last_scan_count']}")
                
                if new_urls:
                    logging.info(f"Detected {len(new_urls)} new listings in this scan")
    else:
        # One-time scan for old listings
        run_detector(args.mode, args.site, args.pages)

if __name__ == "__main__":
    main()
