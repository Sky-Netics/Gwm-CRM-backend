
import requests
import json
import time
from cleaner import Cleaner  # وارد کردن کلاس Cleaner به‌جای ماژول کلی
from cleaner import main as main_cleaner
# file paths for input and output
input_file = "shab_all_data.json"
output_file = "shab_detailed_data.json"

def load_old_ads():
    """ load previously saved detailed ads (to avoid duplicates)"""
    try:
        with open(output_file, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return []
    
def save_ads(all_ads):
    """ Save the full list of ads (including new ones)"""
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(all_ads, f, ensure_ascii=False, indent=2)

def get_new_ads(existing_ids):
    """ Get detailed information for new ads that haven't been saved yet"""
    with open(input_file, "r", encoding="utf-8") as f:
        houses = json.load(f)
    new_ads = []

    for i, house in enumerate(houses, start=1):
        print(f"Processing item {i} of {len(houses)}")
        house_id = house.get("id")
        
        # skip if ID is missing or already processed
        if not house_id or house_id in existing_ids:
            continue

        # API endpoint for detailed house information                
        url = f"https://api.shab.ir/api/fa/sandbox/v_1_4/house/{house_id}"

        try:
            response = requests.get(url)
            if response.status_code == 200:
                detail = response.json().get("data", {})

                title = detail.get("title", "unknown")

                img_links = []
                img_records = detail.get("pictures", {}).get("records", [])
                for img in img_records:
                    if isinstance(img, dict):
                        img_link = img.get("path")
                        if img_link:
                            img_links.append(img_link)

                metr = detail.get("building_area", "unknown")
    
                location = detail.get("location", {})
                city = location.get("city", "")
                village = location.get("village", "")
                if village and city:
                    address = f"{city}, {village}" 
                elif city:
                    address = city
                elif village:
                    address = village    
                else:
                    address = "unknown"

                pricing = detail.get("pricing", {})    
                price = pricing.get("price_to_show", {})
                price_amount = price.get("amount")
                currency = price.get("currency_name", "")

                if price_amount is not None:
                    final_price = f"{price_amount:,} {currency}"
                else:
                    final_price = "" 

                filled_cats = detail.get("features", {}).get("filled_categories", {})
                available_features = []
                for cat_name, features in filled_cats.items():
                    for f in features:
                        if isinstance(f, dict) and f.get("is_active") == 1:
                            label = f.get("feature_label")
                            if label:
                                available_features.append(label)

                rating = detail.get("rates", {}).get("rank", "unknown")

                rules = detail.get("rules", {}).get("records", {})

                checkin_time = detail.get("rules", {}).get("records", {}).get("checkin", "unknown")

                checkout_time = detail.get("rules", {}).get("records", {}).get("checkout", "unknown")

                host_name = detail.get("host", {}).get("name", "unknown")

                capacity = detail.get("rules", {}).get("records", {}).get("accommodates", "unknown")
                max_capacity = detail.get("rules", {}).get("records", {}).get("max_accommodates", "unknown")

                ad_url = f"https://www.shab.ir/houses/show/{house_id}"
                
                # append new ad data to the list
                new_ads.append({
                    "url": ad_url,
                    "id": house_id,
                    "title": title,
                    "img_liks": img_links,
                    "metr": metr,
                    "address": address,
                    "price": final_price,
                    "facilities": available_features,
                    "rating": rating,
                    "rules": rules,
                    "checkin_time": checkin_time,
                    "checkout_time": checkout_time,
                    "host_name": host_name,
                    "capacity": f"standard{capacity} / maximum {max_capacity}",
                })

            time.sleep(0.1) # short delay between requests to avoid rate limits
        except Exception as e:
            print(f"Error in {house_id}: {e}")
    return new_ads    

def main():
    """ main function that coordinates loading, scraping, saving, and cleaning"""
    old_ads = load_old_ads()
    old_ids = {ad["id"] for ad in old_ads if "id" in ad}
    new_ads = get_new_ads(old_ids)
    if new_ads:
        print(f"{len(new_ads)} new ads found.")
        old_ads.extend(new_ads)
        save_ads(old_ads)
        print("Starting cleaner script...")
        # ایجاد یک نمونه از Cleaner و اجرای clean_pipeline
        cleaner = Cleaner(shab_file=output_file, jabama_file="jabama_scraper.json")
        cleaner.clean_pipeline()
        main_cleaner()
    else:
        main_cleaner()
        print("No new ads.")

# run main function every 5 minutes
if __name__ == "__main__":
    while True:
        main()
        time.sleep(300)
